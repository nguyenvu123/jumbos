<?php
/**
 * @package Wordpress
 * @since wpdance
 **/
	require_once get_template_directory()."/framework/abstract.php";
	$tvlgiao_wpdance_theme = new Tvlgiao_Wpdance_GeneralTheme();
	$tvlgiao_wpdance_theme->tvlgiao_wpdance_init();
?>